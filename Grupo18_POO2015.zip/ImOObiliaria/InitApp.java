public class InitApp
{
    private static ImOObiliaria imobiliaria;
    
    public static ImOObiliaria initApp (){
        imobiliaria = new ImOObiliaria ();
        return imobiliaria;
    }

}
