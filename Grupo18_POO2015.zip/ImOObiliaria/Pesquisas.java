

public interface Pesquisas
{
      public int getnumeroQuartos();
      public int getnumeroWC();
}
