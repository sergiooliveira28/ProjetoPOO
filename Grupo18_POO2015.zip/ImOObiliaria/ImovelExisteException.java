public class ImovelExisteException extends Exception
{
    ImovelExisteException(String message){
       super(message);
    }
}
