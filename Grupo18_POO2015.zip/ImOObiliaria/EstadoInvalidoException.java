public class EstadoInvalidoException extends Exception
{
    EstadoInvalidoException(String message){
       super(message);
    }
}
