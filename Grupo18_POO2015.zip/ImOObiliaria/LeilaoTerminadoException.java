public class LeilaoTerminadoException extends Exception
{
    LeilaoTerminadoException(String message){
       super(message);
    }
}
