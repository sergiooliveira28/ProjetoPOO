public class SemAutorizacaoException extends Exception
{
    SemAutorizacaoException(String message){
       super(message);
    }
}
