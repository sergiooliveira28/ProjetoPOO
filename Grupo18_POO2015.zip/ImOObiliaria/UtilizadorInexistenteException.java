public class UtilizadorInexistenteException extends Exception
{
    UtilizadorInexistenteException(String message){
       super(message);
    }
}
