public class UtilizadorExistenteException extends Exception
{
    UtilizadorExistenteException(String message){
       super(message);
    }
}
