public class TipoInvalidoException extends Exception
{
    TipoInvalidoException(String message){
       super(message);
    }
}

