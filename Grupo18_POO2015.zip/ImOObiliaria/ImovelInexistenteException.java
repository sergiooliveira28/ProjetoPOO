public class ImovelInexistenteException extends Exception
{
    ImovelInexistenteException(String message){
       super(message);
    }
}
