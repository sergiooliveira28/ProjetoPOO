public class Consulta
{
    private int contagem;
    private Imovel imovel;
    
    public Consulta(){
        this.contagem = 0;
    }
    
    public int getContagem(){return this.contagem;}
    
    public void setContagem(int ccontagem){this.contagem = ccontagem;}
    
    public Imovel getImovel(){return this.imovel;}
    public void setImovel(Imovel ii){this.imovel = ii;}
    
    
}
