
public interface Habitavel
{
      public boolean getHabitavel();
      public double getPrecoPedido();
}